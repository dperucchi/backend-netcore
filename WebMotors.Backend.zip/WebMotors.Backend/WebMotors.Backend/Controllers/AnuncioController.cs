﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using WebMotors.Backend.Data;
using WebMotors.Backend.Models;

namespace WebMotors.Backend.Controllers
{
    public class AnuncioController : Controller
    {
        private readonly AppDbContext _context;

        public AnuncioController(AppDbContext context)
        {
            _context = context;
        }

        // GET: AnuncioWebmotors
        public async Task<IActionResult> Index()
        {
            return View(await _context.tb_AnuncioWebmotors.ToListAsync());
        }

        // GET: AnuncioWebmotors/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var anuncioWebmotors = await _context.tb_AnuncioWebmotors
                .FirstOrDefaultAsync(m => m.ID == id);
            if (anuncioWebmotors == null)
            {
                return NotFound();
            }

            return View(anuncioWebmotors);
        }

        // GET: AnuncioWebmotors/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: AnuncioWebmotors/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(AnuncioWebmotors anuncioWebmotors)
        {

            if (ModelState.IsValid)
            {
                anuncioWebmotors.Marca = RetornaSemID(anuncioWebmotors.Marca);
                anuncioWebmotors.Modelo = RetornaSemID(anuncioWebmotors.Modelo);
                anuncioWebmotors.Versao = RetornaSemID(anuncioWebmotors.Versao);

                _context.Add(anuncioWebmotors);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(anuncioWebmotors);
        }

        private string RetornaSemID(string dado)
        {
            string dadoTratado = dado.Substring(dado.IndexOf("|") + 1);
            return dadoTratado;
        }

        // GET: AnuncioWebmotors/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var anuncioWebmotors = await _context.tb_AnuncioWebmotors.FindAsync(id);
            if (anuncioWebmotors == null)
            {
                return NotFound();
            }
            return View(anuncioWebmotors);
        }

        // POST: AnuncioWebmotors/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, AnuncioWebmotors anuncioWebmotors)
        {
            if (id != anuncioWebmotors.ID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(anuncioWebmotors);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!AnuncioWebmotorsExists(anuncioWebmotors.ID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(anuncioWebmotors);
        }

        // GET: AnuncioWebmotors/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var anuncioWebmotors = await _context.tb_AnuncioWebmotors
                .FirstOrDefaultAsync(m => m.ID == id);
            if (anuncioWebmotors == null)
            {
                return NotFound();
            }

            return View(anuncioWebmotors);
        }

        // POST: AnuncioWebmotors/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var anuncioWebmotors = await _context.tb_AnuncioWebmotors.FindAsync(id);
            _context.tb_AnuncioWebmotors.Remove(anuncioWebmotors);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool AnuncioWebmotorsExists(int id)
        {
            return _context.tb_AnuncioWebmotors.Any(e => e.ID == id);
        }
    }
}
