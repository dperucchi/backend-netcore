﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace WebMotors.Backend.Models
{
    public class AnuncioWebmotors
    {
        [Key]
        public int ID { get; set; }
        
        [Required(ErrorMessage = "O campo {0} é obrigatório")]
        public string Marca { get; set; }

        [Required(ErrorMessage = "O campo {0} é obrigatório")]
        public string Modelo { get; set; }

        [Required(ErrorMessage = "O campo {0} é obrigatório")]
        public string Versao { get; set; }

        [Required(ErrorMessage = "O campo {0} é obrigatório")]
        public int Ano { get; set; }

        [Required(ErrorMessage = "O campo {0} é obrigatório")]
        public int Quilometragem { get; set; }

        [Required(ErrorMessage = "O campo {0} é obrigatório")]
        public string Observacao { get; set; }
    }
}
