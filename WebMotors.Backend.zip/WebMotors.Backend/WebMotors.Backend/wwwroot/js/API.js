﻿var marcas = obterMarca();

function obterMarca() {
    var url = "https://desafioonline.webmotors.com.br/api/OnlineChallenge/Make";
    let request = new XMLHttpRequest();
    request.open("GET", url, false);
    request.send();
    return request.responseText;
}

function criaMarcas() {
    $.each(JSON.parse(marcas), function (i, marca) {
        $("#marcas").append($('<option>', {
            value: marca.ID + '|' + marca.Name,
            text: marca.Name
        }))
    })
}

function obterModelo(marca) {
    var url = "https://desafioonline.webmotors.com.br/api/OnlineChallenge/Model?MakeID={0}";
    let request = new XMLHttpRequest();
    var id = marca.substring(0, marca.indexOf('|'));

    request.open("GET", url.replace("{0}", id), false);
    request.send();
    criaModelos(request.responseText);
}

function criaModelos(modelos) {
    var selectElement = document.getElementById("modelos");
    for (var i = selectElement.length - 1; i >= 0; i--) {
        if (selectElement.options[i].value != "") {
            selectElement.remove(i);
        }
    }
    $.each(JSON.parse(modelos), function (i, modelo) {
        $("#modelos").append($('<option>', {
            value: modelo.ID + '|' + modelo.Name,
            text: modelo.Name,
        }))
    })
}

function obterVersao(modelo) {

    var url = "https://desafioonline.webmotors.com.br/api/OnlineChallenge/Version?ModelID={0}";
    let request = new XMLHttpRequest();
    var id = modelo.substring(0, modelo.indexOf('|'));

    request.open("GET", url.replace("{0}", id), false);
    request.send();
    criaVersoes(request.responseText);
}

function criaVersoes(versoes) {
    var selectElement = document.getElementById("versoes");
    for (var i = selectElement.length - 1; i >= 0; i--) {
        if (selectElement.options[i].value != "") {
            selectElement.remove(i);
        }
    }
    $.each(JSON.parse(versoes), function (i, versao) {
        $("#versoes").append($('<option>', {
            value: versao.ID+'|'+versao.Name,
            text: versao.Name,
        }))
    })
}

$(document).ready(function () {

    criaMarcas();

    $("#marcas").change(function () {
        var marca = $(this).val()
        obterModelo(marca);
    })
    $("#modelos").change(function () {
        var modelo = $(this).val()
        obterVersao(modelo);
    })
})
